﻿namespace Analyz
{
    partial class ChecksForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.BackButton = new System.Windows.Forms.Button();
            this.ApplyButton = new System.Windows.Forms.Button();
            this.AddAnswerButton = new System.Windows.Forms.Button();
            this.EditAnswerButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(776, 306);
            this.dataGridView1.TabIndex = 0;
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(606, 366);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(182, 72);
            this.BackButton.TabIndex = 1;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = true;
            // 
            // ApplyButton
            // 
            this.ApplyButton.Location = new System.Drawing.Point(417, 366);
            this.ApplyButton.Name = "ApplyButton";
            this.ApplyButton.Size = new System.Drawing.Size(142, 72);
            this.ApplyButton.TabIndex = 2;
            this.ApplyButton.Text = "Готово";
            this.ApplyButton.UseVisualStyleBackColor = true;
            // 
            // AddAnswerButton
            // 
            this.AddAnswerButton.Location = new System.Drawing.Point(12, 366);
            this.AddAnswerButton.Name = "AddAnswerButton";
            this.AddAnswerButton.Size = new System.Drawing.Size(158, 72);
            this.AddAnswerButton.TabIndex = 3;
            this.AddAnswerButton.Text = "Добавить ответ";
            this.AddAnswerButton.UseVisualStyleBackColor = true;
            // 
            // EditAnswerButton
            // 
            this.EditAnswerButton.Location = new System.Drawing.Point(227, 366);
            this.EditAnswerButton.Name = "EditAnswerButton";
            this.EditAnswerButton.Size = new System.Drawing.Size(149, 72);
            this.EditAnswerButton.TabIndex = 4;
            this.EditAnswerButton.Text = "Редактировать ответ";
            this.EditAnswerButton.UseVisualStyleBackColor = true;
            this.EditAnswerButton.Click += new System.EventHandler(this.EditAnswerButton_Click);
            // 
            // ChecksForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.EditAnswerButton);
            this.Controls.Add(this.AddAnswerButton);
            this.Controls.Add(this.ApplyButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.dataGridView1);
            this.Name = "ChecksForm";
            this.Text = "ChecksForm";
            this.Load += new System.EventHandler(this.ChecksForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button ApplyButton;
        private System.Windows.Forms.Button AddAnswerButton;
        private System.Windows.Forms.Button EditAnswerButton;
    }
}