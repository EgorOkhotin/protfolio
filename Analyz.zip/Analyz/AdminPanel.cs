﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyz
{
    public partial class AdminPanel : Form
    {
        public AdminPanel()
        {
            FormClosing += AdminPanel_FormClosing;
            InitializeComponent();
        }

        private void AdminPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            //_formClose.Invoke();
        }

        private void AdminPanel_Load(object sender, EventArgs e)
        {

        }

        private void ServicesButton_Click(object sender, EventArgs e)
        {
            var f = new ServicesForm(); //set from context
            f.StartPosition = FormStartPosition.CenterParent;
            f.ShowDialog();
            //Visible = false;
            //f.Visible = true;
        }

        private void ChecksButton_Click(object sender, EventArgs e)
        {
            var f = new ChecksForm();
            f.StartPosition = FormStartPosition.CenterParent;
            f.ShowDialog();
            //this.Visible = false;
            //f.Visible = true;
        }
    }
}
