﻿namespace Analyz
{
    partial class AdminPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ChecksButton = new System.Windows.Forms.Button();
            this.ServicesButton = new System.Windows.Forms.Button();
            this.BackToMenuButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ChecksButton
            // 
            this.ChecksButton.Location = new System.Drawing.Point(500, 84);
            this.ChecksButton.Name = "ChecksButton";
            this.ChecksButton.Size = new System.Drawing.Size(231, 98);
            this.ChecksButton.TabIndex = 1;
            this.ChecksButton.Text = "Проверки";
            this.ChecksButton.UseVisualStyleBackColor = true;
            this.ChecksButton.Click += new System.EventHandler(this.ChecksButton_Click);
            // 
            // ServicesButton
            // 
            this.ServicesButton.Location = new System.Drawing.Point(124, 84);
            this.ServicesButton.Name = "ServicesButton";
            this.ServicesButton.Size = new System.Drawing.Size(231, 98);
            this.ServicesButton.TabIndex = 2;
            this.ServicesButton.Text = "Услуги";
            this.ServicesButton.UseVisualStyleBackColor = true;
            this.ServicesButton.Click += new System.EventHandler(this.ServicesButton_Click);
            // 
            // BackToMenuButton
            // 
            this.BackToMenuButton.Location = new System.Drawing.Point(124, 305);
            this.BackToMenuButton.Name = "BackToMenuButton";
            this.BackToMenuButton.Size = new System.Drawing.Size(231, 98);
            this.BackToMenuButton.TabIndex = 3;
            this.BackToMenuButton.Text = "Возврат в главное меню";
            this.BackToMenuButton.UseVisualStyleBackColor = true;
            // 
            // AdminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BackToMenuButton);
            this.Controls.Add(this.ServicesButton);
            this.Controls.Add(this.ChecksButton);
            this.Name = "AdminPanel";
            this.Text = "AdminPanel";
            this.Load += new System.EventHandler(this.AdminPanel_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ChecksButton;
        private System.Windows.Forms.Button ServicesButton;
        private System.Windows.Forms.Button BackToMenuButton;
    }
}