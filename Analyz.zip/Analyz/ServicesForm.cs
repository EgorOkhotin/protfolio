﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyz
{
    public partial class ServicesForm : Form
    {
        //Point _defaultLocation;
        //Action _formClosed;
        int nextId = -1;
        public ServicesForm()
        {
            FormClosing += ServicesForm_FormClosing;
            //_defaultLocation = Location;
            //_formClosed = formClosed;
            InitializeComponent();
        }

        private void ServicesForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //_formClosed.Invoke();
        }

        private void ServicesForm_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("Id", "№");
            dataGridView1.Columns[0].ReadOnly = true;

            dataGridView1.Columns.Add("Name", "Название услуги");

            dataGridView1.Columns.Add("Probablie", "Вероятность");
            dataGridView1.Columns[2].ValueType = typeof(double);

            for(int i=1; i<7; i++)
                dataGridView1.Rows.Add(i, ((CreditType)i).ToString(), Program.Context.StartedConclusions[i-1]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(nextId, "", 0.0);
            nextId++;
        }

        private void Apply_Click(object sender, EventArgs e)
        {
            if (IsValidProbablies() && IsValidNames())
            {
                Program.Context.ChangeStartConclusion(GetConclusions());
                MessageBox.Show("Applied!");
                this.Close();
            }
            else MessageBox.Show("Wrong parametrs");
        }

        private bool IsValidProbablies()
        {
            var rowsCount = dataGridView1.Rows.Count-1;
            double p = 0;
            for(int i=0; i<rowsCount; i++)
            {
                if (dataGridView1[2, i].Value == null) return false;
                p += (double)dataGridView1[2, i].Value;
            }
            return p <= 1d;
        }

        private bool IsValidNames()
        {
            var rowsCount = dataGridView1.Rows.Count-1;
            var names = new List<string>();
            for (int i = 0; i < rowsCount; i++)
            {
                var n = dataGridView1[1, i].Value as string;
                if (n != null)
                {
                    if (names.FirstOrDefault(x => x.Equals(n))!= null)
                        return false;
                    else names.Add(n);
                }
                else return false;
            }
            return true;
        }

        private double[] GetConclusions()
        {
            var rowsCount = dataGridView1.Rows.Count - 1;
            var result = new List<double>();
            for (int i = 0; i < rowsCount; i++)
            {
                result.Add((double)dataGridView1[2, i].Value);
            }
            return result.ToArray();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
