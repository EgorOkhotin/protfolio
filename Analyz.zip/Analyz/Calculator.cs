﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyz
{
    class Calculator
    {
        List<IntermediateResult> results;
        public Calculator(double[] defaultProbablies)
        {
            results = new List<IntermediateResult>();
            results.Add(new IntermediateResult(defaultProbablies));
        }

        public Conclusion[] Conclusions { get; private set; }

        public double[] AddAnswerConclusion(Answer a)
        {
            var probablies = a.Conclusions.OrderBy(x => x.CreditType).Select(x => x.Value).ToArray();
            var lastResult = results.Last();
            var denominator = CalculateDenominator(probablies, lastResult);
            var calculated = new List<double>();
            for(int i=0; i<probablies.Length; i++)
            {
                calculated.Add(CalculateCell(
                    probablies,
                    lastResult,
                    i,
                    denominator
                    ));
            }
            results.Add(new IntermediateResult(calculated.ToArray()));
            return calculated.ToArray();
        }

        private double CalculateCell(
            double[] probalies, 
            IntermediateResult last, 
            int serviceIndex,
            double denominator)
        {
            return (last.Results[serviceIndex] * probalies[serviceIndex]) / denominator;
        }

        private double CalculateDenominator(double[] probablies, IntermediateResult last)
        {
            decimal result = 0;
            for(int i=0; i<probablies.Length; i++)
            {
                result += (decimal)probablies[i] * (decimal)last.Results[i];
            }
            return (double)result;
        }

        private double CalculateApriorEntrophy(double[] probablies)
        {
            decimal result = 0;
            for(int i=0; i<probablies.Length; i++)
            {
                result += (decimal)(probablies[i] * Math.Log(probablies[i], 2.0));
            }
            return (double)((-1m)*result);
        }

        private double CalculateAposteriorEnthropy(
            IntermediateResult last, 
            double[] probablies,
            double[] calculated)
        {
            decimal pk = 0;
            for(int i=0;i<probablies.Length;i++)
            {
                pk += (decimal)probablies[i] + (decimal)last.Results[i];
            }

            decimal hkej = 0;
            for(int i=0; i<calculated.Length; i++)
            {
                hkej += (decimal)(calculated[i] * Math.Log(calculated[i], 2));
            }
            hkej += -1m;

            throw new NotImplementedException();
        }

        private class IntermediateResult
        {
            public IntermediateResult(double[] results)
            {
                Results = results;
            }
            public double[] Results { get; set; }
            public IntermediateResult(int k)
            {
                Results = new double[k];
            }

            public static IntermediateResult Create(IntermediateResult r)
            {
                return new IntermediateResult(r.Results.Length);
            }
        }
    }
}
