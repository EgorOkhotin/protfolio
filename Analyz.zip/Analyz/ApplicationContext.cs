﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using LiteDB;

namespace Analyz
{
    class ApplicationContext
    {
        private string _fileName;
        public ApplicationContext(string fileName)
        {
            _fileName = fileName;
            //EnsureCreate(LoadFromJson());
            var r = ReadBase(fileName);
            //Questions = r.Item1;
            //StartedConclusions = r.Item2.Probablies;
            
        }
        public List<Question> Questions { get; private set; }
        public double[] StartedConclusions { get; private set; }

        public void DeleteQuestion(Question q)
        {
            using (var db = new LiteDatabase(_fileName))
            {
                db.GetCollection<Question>().Delete(x => x.QuestionId == q.QuestionId);
                var list = Questions.ToList();
                list.RemoveAll(x => x.QuestionId == q.QuestionId);
                Questions = list;
            }
        }

        public void AddQuestion(Question q)
        {
            using (var db = new LiteDatabase(_fileName))
            {
                q.QuestionId = Questions.Max(x => x.QuestionId) + 1;
                db.GetCollection<Question>().Insert(q);
                var list = Questions.ToList();
                list.Add(q);
                Questions = list;
            }
        }

        public void ChangeStartConclusion(double[] probablies)
        {
            using (var db = new LiteDatabase(_fileName))
            {
                var conclusions = db.GetCollection<StartProbablies>();
                conclusions.Delete(x => x.StartProbabliesId == 1);
                conclusions.Insert(new StartProbablies() { StartProbabliesId = 1, Probablies = probablies });
                StartedConclusions = probablies;
            }
        }
        private void EnsureCreate(IEnumerable<Question> qs)
        {
            using (var db = new LiteDatabase(_fileName))
            {
                var collection = db.GetCollection<Question>();
                collection.Delete(x => x.QuestionId >= 0);
                int id = 1;
                foreach(var q in qs)
                {
                    q.QuestionId = id;
                    collection.Insert(q);
                    id++;
                }
            }
        }

        private (List<Question>, StartProbablies) ReadBase(string fileName)
        {
            using (var db = new LiteDatabase(fileName))
            {
                Questions = db.GetCollection<Question>().FindAll().ToList();
                var p = db.GetCollection<StartProbablies>().FindAll().First();
                StartedConclusions = p.Probablies;
                return (Questions, p);
            }
        }

        private IEnumerable<Question> LoadFromJson()
        {
            using (var file = new FileStream("questions.json", System.IO.FileMode.Open, FileAccess.Read))
            {
                using (var reader = new StreamReader(file))
                {
                    return (JsonConvert.DeserializeObject<DbSchema>(reader.ReadToEnd())).Questions;
                }
            }
        }

        private class DbSchema
        {
            public Question[] Questions { get; set; }
        }

        private class StartProbablies
        {
            public int StartProbabliesId { get; set; }
            public double[] Probablies { get; set; }
        }
    }
}
