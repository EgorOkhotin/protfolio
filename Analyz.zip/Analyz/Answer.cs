﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyz
{
    public class Answer
    {
        public Answer()
        {

        }

        public string Text { get; set; }
        public IEnumerable<Conclusion> Conclusions { get; set; } 

        public bool IsValid()
        {
            return Convert.ToInt32(Conclusions.Select(x => x.Value).Sum()) == 1;
        }
    }
}
