﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyz
{
    public partial class EditQuestionForm : Form
    {
        Question _edit;
        public EditQuestionForm(Question q)
        {
            _edit = q;
            InitializeComponent();
        }

        private void EditQuestionForm_Load(object sender, EventArgs e)
        {
            
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {

        }

        private bool IsValidAnswerNames()
        {
            var rowCount = dataGridView1.RowCount - 1;
            for (int i = 0; i < rowCount; i++)
            {
                if (dataGridView1[1, i].Value == null) return false;
            }
            return true;
        }

        private bool IsValidProbabilities()
        {
            return false;
        }
    }
}
