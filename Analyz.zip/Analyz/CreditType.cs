﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyz
{
    public enum CreditType
    {
        CreditCard = 1,
        Credit,
        Mortgage,
        CarLoan,
        Deposit,
        MIF,
        SavingInsurance
    }
}
