﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyz
{
    public partial class ChecksForm : Form
    {
        //Action _formClosed;
        Dictionary<int, string> _questions;
        public ChecksForm()
        {
            FormClosing += ChecksForm_FormClosing;
            InitializeComponent();
            _questions = new Dictionary<int, string>();
        }

        private void ChecksForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //_formClosed.Invoke();
        }

        private void EditAnswerButton_Click(object sender, EventArgs e)
        {
            var q = GetCurrentQuestion();
            var f = new EditQuestionForm(q);
            f.StartPosition = FormStartPosition.CenterParent;
            f.ShowDialog();
        }

        private Question GetCurrentQuestion()
        {
            var row = dataGridView1.CurrentRow;
            var qId = (int)row.Cells[0].Value;
            return Program.Context.Questions.First(x =>x.Text == _questions[qId]);
        }

        private void ChecksForm_Load(object sender, EventArgs e)
        {
            var questions = Program.Context.Questions.ToList();
            dataGridView1.Columns.Add("Id", "Id");
            dataGridView1.Columns.Add("Name", "Text");
            foreach (var q in questions)
            {
                dataGridView1.Rows.Add(q.QuestionId, q.Text);
                _questions.Add(q.QuestionId, q.Text);
            }
        }
    }
}
