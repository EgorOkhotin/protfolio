﻿using System;
using System.Collections.Generic;
using System.Text;
using ReactiveUI;

namespace AvaloniaApplication1.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
