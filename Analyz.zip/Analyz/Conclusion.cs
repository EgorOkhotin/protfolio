﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Analyz
{
    public class Conclusion
    {
        public Conclusion()
        {

        }
        public Conclusion(CreditType type, double val)
        {

        }

        public CreditType CreditType { get; set; }
        public double Value { get; set; }
    }
}
