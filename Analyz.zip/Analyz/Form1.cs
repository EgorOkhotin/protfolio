﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analyz
{
    public partial class Form1 : Form
    {
        //private ApplicationContext _context;
        private Calculator _calculator;
        public Form1()
        {
            //_context = new ApplicationContext("questions.db");
            _calculator = new Calculator(Program.Context.StartedConclusions);

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void AdminButton_Click(object sender, EventArgs e)
        {
            AdminPanel f = new AdminPanel();
            f.StartPosition = FormStartPosition.CenterParent;
            f.ShowDialog();
            //this.Visible = false;
            //f.Visible = true;
        }

        private void UserModeButton_Click(object sender, EventArgs e)
        {

        }
    }
}
